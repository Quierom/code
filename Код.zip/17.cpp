﻿#include <iostream>
#include <string>

int main()
{
    std::string vowels = "aeiouy", consonants = "bcdfghjklmnpqrstvwxz", alphabet = "abcdefghijklmnopqrstuvwxyz", str, rez = "", str_rez="", str_rez1 = "";
    int pos = 0;
    bool eqw = false;
    std::cin >> str;

    //при случае когда встретили гласную
    for (int i = 0; i < str.length(); i++) {
        for (int j = 0; j < vowels.length(); j++) {
            if (str[i] == vowels[j]) {
                rez = "glas";
                break;
            }
        }
        if (rez != "glas") {
            for (int j = 0; j < consonants.length(); j++) {
                if (str[i] == consonants[j]) {
                    rez = "sogl";
                    break;
                }
            }
        }
        
        if (rez == "glas") {
            for (int k = 0; k < alphabet.length() - 1; k++) {
                if (str[i] == alphabet[k]) {
                    str_rez += alphabet[k + 1];
                    str_rez1 += "1";
                }
            }

        }
        if (rez == "sogl") {
            for (int k = 0; k < alphabet.length() - 1; k++) {
                if (str[i] == alphabet[k]) {             
                    pos = k;
                }
            }
            for (int k = pos + 1; k < alphabet.length() - 1; k++) {
                for (int j = 0; j < vowels.length(); j++) {
                    if (alphabet[k] == vowels[j]) {
                        str_rez += alphabet[k];
                        str_rez1 += std::to_string(k-pos);
                        eqw = true;
                        break;
                    }
                }
                if (eqw == true) {
                    eqw = false;
                    break;
                }
            }
        }
        
        rez = "";
    }
    std::cout << str_rez << std::endl;;
    std::cout << str_rez1;
}
    
    //при случае когда встретили согласную



//Шифрование
//
//Вводится строка которую необходимо зашифровать по следующему правилу : каждую согласную кодируем на ближайшую гласную запоминая при этом расстояние между согласной и гласной в отдельную строку.
//Каждую гласную кодируем согласной и так же записываем длину между гласной и согласной в отдельную строку.Выводится сама строка закодированная и далее цифры сдвига.
//Буква а закодируется b.b закодируется e и тд.
//
//Например :
//    abc
//    bee
//    132
//
//    Примечание : для дешифрования смотрится буква в закодированной строке bee и цифра на месте буквы которую кодируем.
//    b и цифра 1->сдвиг влево от b на 1
//    e и цифра 3->сдвиг влево от e на 3