﻿#include <iostream>
#include <string>

int main()
{
    std::string line, line1, line2;
    int z = 1;

    std::cin >> line;

    for (int i = 0; i < line.length(); i++) {
        if (i % 2 != 0) {
            line1 += line[i];
        }
        else {
            line2 += line[i];
        }
    } 
    std::cout << line2 << std::endl;
    std::cout << line1;
}

//Индексы в строке
//
//Входные данные
//На вход подается строка.Вывести все символы с четными индексами в одну строку, с нечетными в другую.
//
//Пример:
//abcdefg
//aceg
//bdf
