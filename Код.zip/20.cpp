﻿#include <iostream>
#include <string>

int main()
{
    std::string str = "", str1 = "";
    char asc;
    int z;
    getline(std::cin, str);
    str += " ";
    for (int i = 0; i < str.length(); i++) {
        if (str[i] != ' ') {
            str1 += str[i];
        }
        else {
            z = stoi(str1);
            if (i != str.length() - 1) {
                std::cout << char(z) << " ";
                str1 = "";
            }
            else {
                std::cout << char(z);
                str1 = "";
            }
        }
    }
}


//И снова ASCII❤️
//
//Вводится строка состоящая из чисел, вывести по данным номерам элементы из ASCII таблицы.
//
//Пример:
//99 97 98
//c a b
